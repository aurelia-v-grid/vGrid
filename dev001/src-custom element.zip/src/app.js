export class App {
  configureRouter(config, router){
    config.title = 'TEST';
    config.map([
      { route: ['','sample01'], name: 'sample01', moduleId: './sample01',  nav: true, title:'sample01' },
      { route: ['sample02'], name: 'sample02', moduleId: './sample02',  nav: true, title:'sample02' }
    ]);

    this.router = router;
  }
}
