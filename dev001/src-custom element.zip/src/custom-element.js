import {inject, noView, ViewCompiler, ViewSlot, Container, ViewResources} from 'aurelia-framework';

@noView
@inject(Element, ViewCompiler, ViewSlot, Container, ViewResources)
export class customElement{
  title = "custom"
  /*
   The view-model's constructor is called first.
   */
  constructor(element, vc, vs, container, resources){
    this.viewCompiler = vc;
    this.viewSlot = vs;
    this.container = container;
    this.resources = resources;
    this.element = element





  }




  /*
   If the view-model implements the created callback it is invoked next.
   At this point in time, the view has also been created and both the view-model and the view are connected to their controller.
   The created callback will recieve the instance of the "owningView". This is the view that the component is declared inside of.
   If the component itself has a view, this will be passed second.
   */
  created(owningView: View, myView: View){

    console.log("created"+":"+this.title)
    this.owningView = owningView;
    this.myView = myView;


  }


  /*Databinding is then activated on the view and view-model.
   If the view-model has a bind callback, it will be invoked at this time.
   The "binding context" to which the component is being bound will be passed first.
   An "override context" will be passed second.
   The override context contains information used to traverse the parent hierarchy
   and can also be used to add any contextual properties that the component wants to add.*/
  bind(bindingContext: Object, overrideContext: Object){
    console.log("bind"+":"+this.title)
    this.bindingContext = bindingContext;
    this.overrideContext = overrideContext;
  }

  xtitle = "ouch";
  clickMe(){
    debugger;
    this.xtitle = "wow"
  }

  /*
   Next, the component is attached to the DOM (in document). If the view-model has an attached callback, it will be invoked at this time.
   * */
  attached(){


    //generate view from string
    let viewFactory =  this.viewCompiler.compile('<template><button click.trigger="clickMe()">${xtitle}</button></template>', this.resources);
    let view = viewFactory.create(this.container);
    this.viewSlot.add(view);
    this.viewSlot.bind(this.bindingContext);
    this.viewSlot.attached();


    //genrate view within some other node lik I need in my grid with its own context (row)
    var x = document.createElement("div")
    this.element.appendChild(x)

    let viewFactory2 =  this.viewCompiler.compile('<template><button click.trigger="clickMe()">${xtitle}</button></template>', this.resources);
    let view2 = viewFactory2.create(this.container);
    let bindingContext = {
      xtitle:'Clickxx1 Me',
      clickMe:()=>{
        alert("wow")
      }
    };
    this.viewSlotNew = new ViewSlot(x, true);
    this.viewSlotNew.add(view2);
    this.viewSlotNew.bind(bindingContext);
    this.viewSlotNew.attached();


  }

  /*
   After a component is detached, it's usually unbound. If your view-model has the unbind callback, it will be invoked during this process.
   */
  detached(){
    console.log("detached"+":"+this.title)

  }


  /*
   After a component is detached, it's usually unbound. If your view-model has the unbind callback, it will be invoked during this process.
   */
  unbind(){
    console.log("unbind"+":"+this.title)
  }


}
