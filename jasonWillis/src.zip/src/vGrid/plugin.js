export function configure(config) {
  config.globalResources('vGrid/v-grid-col','vGrid/v-grid-cell-row','vGrid/v-grid.js', 'vGrid/v-grid-atts');
}
