//main idea/source https://github.com/callmenick/Custom-Context-Menu
//just testing atm

import {inject, customAttribute} from 'aurelia-framework';


var ContextMenu = class{

  constructor(element) {
    this.element = element;
    this.contextMenuClassName = "v-grid-context-menu";
    this.contextMenuItemClassName = "v-grid-context-menu__item";
    this.contextMenuLinkClassName = "v-grid-context-menu__link";
    this.contextMenuActive = "v-grid-context-menu--active";


    this.taskItemInContext;

    this.clickCoords;
    this.clickCoordsX;
    this.clickCoordsY;


    this.menuState = 0;
    this.menuWidth;
    this.menuHeight;
    this.menuPosition;
    this.menuPositionX;
    this.menuPositionY;

    this.windowWidth;
    this.windowHeight;





  }


  attached() {
    this.addListener();

  }


  detached() {
    this.removeListener();
  }


  addListener() {
    this.contextListenerBinded = this.contextListener.bind(this);
    this.element.addEventListener("contextmenu", this.contextListenerBinded);
  }


  removeListener() {
    this.element.removeEventListener("contextmenu", this.contextListenerBinded);
  }


  contextListener(e) {
      this.taskItemInContext = this.clickInsideElement(e, this.classToOpenOn);

      if (this.taskItemInContext) {
        e.preventDefault();
        this.toggleMenuOn();
        this.positionMenu(e);
      } else {
        this.taskItemInContext = null;
        this.toggleMenuOff();
      }
  }


  addMenuClickListner() {
    this.clickListenerBinded = this.clickListener.bind(this);
    document.addEventListener("click", this.clickListenerBinded)
  }

  removeMenuClickListner() {
    document.removeEventListener("click", this.clickListenerBinded)
  }

  clickListener(e) {
     var clickeElIsLink = this.clickInsideElement(e, this.contextMenuLinkClassName);

      if (clickeElIsLink && this.taskItemInContext) {
        e.preventDefault();
        this.menuItemListener(clickeElIsLink);
      } else {
        var button = e.which || e.button;
        if (button === 1) {
          this.toggleMenuOff();
        }
      }

  }



  clickInsideElement(e, className) {
    var el = e.srcElement || e.target;

    if (el.classList.contains(className)) {
      return el;
    } else {
      while (el = el.parentNode) {
        if (el.classList && el.classList.contains(className)) {
          return el;
        }
      }
    }

    return false;
  }


  clickInsideElement(e, className) {
    var el = e.srcElement || e.target;
    if (el.classList.contains(className)) {
      return el;
    } else {
      while (el = el.parentNode) {
        if (el.classList && el.classList.contains(className)) {
          return el;
        }
      }
    }
    return false;
  }


  createMenu() {
    this.menu = document.createElement("nav");
    this.menu.classList.add("v-grid-context-menu");
    this.menu.innerHTML = this.menuHtml();
    document.body.appendChild(this.menu);
    this.menuItems = this.menu.querySelectorAll(".v-grid-context-menu__item");
  }


  removeMenu() {
    document.body.removeChild(this.menu);
    this.menu = null;
    this.menuItems = null;
  }


  toggleMenuOn() {
    if (this.menuState !== 1) {
      this.menuState = 1;
      this.createMenu();
      this.addMenuClickListner();
    }
  }


  toggleMenuOff() {
    if (this.menuState !== 0) {
      this.menuState = 0;
      this.removeMenuClickListner();
      this.removeMenu();

    }
  }


  /**
   * Positions the menu properly.
   */
  positionMenu(e) {
    this.clickCoords = this.getPosition(e);
    this.clickCoordsX = this.clickCoords.x;
    this.clickCoordsY = this.clickCoords.y;

    this.menuWidth = this.menu.offsetWidth + 4;
    this.menuHeight = this.menu.offsetHeight + 4;

    this.windowWidth = window.innerWidth;
    this.windowHeight = window.innerHeight;

    if ((this.windowWidth - this.clickCoordsX) < this.menuWidth) {
      this.menu.style.left = this.windowWidth - this.menuWidth + "px";
    } else {
      this.menu.style.left = this.clickCoordsX + "px";
    }

    if ((this.windowHeight - this.clickCoordsY) < this.menuHeight) {
      this.menu.style.top = this.windowHeight - this.menuHeight + "px";
    } else {
      this.menu.style.top = this.clickCoordsY + "px";
    }
  }


  /**
   * Get's exact position of event.
   */
  getPosition(e) {
    var posx = 0;
    var posy = 0;

    if (!e) var e = window.event;

    if (e.pageX || e.pageY) {
      posx = e.pageX;
      posy = e.pageY;
    } else if (e.clientX || e.clientY) {
      posx = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
      posy = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
    }

    return {
      x: posx,
      y: posy
    }
  }

};

@customAttribute('v-grid-context-menu-header')
@inject(Element)
export class ContextMenuHeader extends ContextMenu{

  menuHtml(){return `
    <ul>
        <li class="v-grid-context-menu__item">
          <a  class="v-grid-context-menu__link" data-action="clearCell">Clear cell</a>
        </li>      
        <li class="v-grid-context-menu__item">
          <a class="v-grid-context-menu__split" data-action="View">Set Filter</a>
        </li>
        <li class="v-grid-context-menu__item">
          <a  class="v-grid-context-menu__link" data-action="Edit">Contains</a>
        </li>
        <li class="v-grid-context-menu__item">
          <a  class="v-grid-context-menu__link" data-action="Delete">Equal to</a>
        </li>        
    </ul>
    `};

  classToOpenOn = "vGrid-queryField";

  menuItemListener(link) {
    console.log("Task action - " + link.getAttribute("data-action"));
    this.toggleMenuOff();
  };

}


