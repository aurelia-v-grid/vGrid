/**
 * Created by vegar on 5/2/2016.
 */
import {inject, customAttribute} from 'aurelia-framework';


@customAttribute('testmenu')
@inject(Element)
export class ContextMenu {

  constructor(element) {
    this.element = element;
  }


  attached() {
    var html = `
  
      <ul class="context-menu__items">
      <li class="context-menu__item">
      <a  class="context-menu__link" data-action="View">View Task</a>
    </li>
    <li class="context-menu__item">
      <a  class="context-menu__link" data-action="Edit">Edit Task</a>
    </li>
    <li class="context-menu__item">
      <a  class="context-menu__link" data-action="Delete">Delete Task</a>
    </li>
    </ul>
    `


    this.menu = document.createElement("nav");
    this.menu.classList.add("context-menu");
    this.menu.innerHTML = html;
    document.body.appendChild(this.menu);
    this.menuItems = this.menu.querySelectorAll(".context-menu__item");

    this.contextListener();
    this.clickListener();
  }


  /**
   * Listens for contextmenu events.
   */
  contextListener() {
    this.element.addEventListener("contextmenu", function (e) {
      this.taskItemInContext = this.clickInsideElement(e, this.taskItemClassName);

      if (this.taskItemInContext) {
        e.preventDefault();
        this.toggleMenuOn();
        this.positionMenu(e);
      } else {
        this.taskItemInContext = null;
        this.toggleMenuOff();
      }
    }.bind(this));
  }


  clickListener() {
    document.addEventListener("click", function (e) {
      var clickeElIsLink = this.clickInsideElement(e, this.contextMenuLinkClassName);

      if (clickeElIsLink && this.taskItemInContext) {
        e.preventDefault();
        this.menuItemListener(clickeElIsLink);
      } else {
        var button = e.which || e.button;
        if (button === 1) {
          this.toggleMenuOff();
        }
      }
    }.bind(this));
  }

  menuItemListener(link) {
    console.log("Task ID - " + this.taskItemInContext.getAttribute("data-id") + ", Task action - " + link.getAttribute("data-action"));
    this.toggleMenuOff();
  }

  clickInsideElement(e, className) {
    var el = e.srcElement || e.target;

    if (el.classList.contains(className)) {
      return el;
    } else {
      while (el = el.parentNode) {
        if (el.classList && el.classList.contains(className)) {
          return el;
        }
      }
    }

    return false;
  }


  detached() {
    $(this.element).off('change');
  }


  clickInsideElement(e, className) {
    var el = e.srcElement || e.target;

    if (el.classList.contains(className)) {
      return el;
    } else {
      while (el = el.parentNode) {
        if (el.classList && el.classList.contains(className)) {
          return el;
        }
      }
    }

    return false;
  }

  contextMenuClassName = "context-menu";
  //contextMenuClassName = "vGrid-queryField";
  contextMenuItemClassName = "context-menu__item";
  contextMenuLinkClassName = "context-menu__link";
  contextMenuActive = "context-menu--active";

  taskItemClassName = "vGrid-queryField";
  taskItemInContext;

  clickCoords;
  clickCoordsX;
  clickCoordsY;


  menuState = 0;
  menuWidth;
  menuHeight;
  menuPosition;
  menuPositionX;
  menuPositionY;

  windowWidth;
  windowHeight;


  /**
   * Positions the menu properly.
   */
  positionMenu(e) {
    this.clickCoords = this.getPosition(e);
    this.clickCoordsX = this.clickCoords.x;
    this.clickCoordsY = this.clickCoords.y;

    this.menuWidth = this.menu.offsetWidth + 4;
    this.menuHeight = this.menu.offsetHeight + 4;

    this.windowWidth = window.innerWidth;
    this.windowHeight = window.innerHeight;

    if ((this.windowWidth - this.clickCoordsX) < this.menuWidth) {
      this.menu.style.left = this.windowWidth - this.menuWidth + "px";
    } else {
      this.menu.style.left = this.clickCoordsX + "px";
    }

    if ((this.windowHeight - this.clickCoordsY) < this.menuHeight) {
      this.menu.style.top = this.windowHeight - this.menuHeight + "px";
    } else {
      this.menu.style.top = this.clickCoordsY + "px";
    }
  }

  toggleMenuOn() {
    if (this.menuState !== 1) {
      this.menuState = 1;
      this.menu.classList.add(this.contextMenuActive);
    }
  }

  /**
   * Turns the custom context menu off.
   */
  toggleMenuOff() {
    if (this.menuState !== 0) {
      this.menuState = 0;
      this.menu.classList.remove(this.contextMenuActive);
    }
  }

  /**
   * Get's exact position of event.
   */
  getPosition(e) {
    var posx = 0;
    var posy = 0;

    if (!e) var e = window.event;

    if (e.pageX || e.pageY) {
      posx = e.pageX;
      posy = e.pageY;
    } else if (e.clientX || e.clientY) {
      posx = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
      posy = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
    }

    return {
      x: posx,
      y: posy
    }
  }


}



