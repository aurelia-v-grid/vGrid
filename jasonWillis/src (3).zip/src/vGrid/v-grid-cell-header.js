/*****************************************************************************************************************
 *    VGridCellRow
 *    Custom element controlling the cell logic
 *    Created by vegar ringdal
 *
 ****************************************************************************************************************/
import {inject, noView, customElement, processContent, bindable} from 'aurelia-framework';
import {VGrid} from './v-grid'

//should I make this into a container and have cells under it?


@noView
@customElement('v-grid-cell-header')
@processContent(false)
@inject(Element, VGrid)
export class VGridCellRow {
  @bindable columnNo;


  columnNoChanged(newValue){
    console.log("changed")
  }

  constructor(element, vGrid) {
    this.element = element;
    this.vGrid = vGrid;
    this.vGridConfig = vGrid.vGridConfig;
  }


  bind(bindingContext) {
    this.bindingContext = bindingContext;
    console.log("nind")


  }


  created() {
    console.log("created")
  }


  attached() {
    this.setStandardClassesAndStyles();
    this.haveFilter = this.vGrid.vGridConfig.addFilter;
    this.attribute = this.vGrid.vGridConfig.attributeArray[this.columnNo];
    var sortIcon = this.getSortIcon(this.attribute);
    if(!this.haveFilter){
      this.label = document.createElement('div');
      this.label.style['line-height'] = this.vGridConfig.headerHeight + "px";
      this.label.style.height = "100%";
      this.label.style.width = this.vGridConfig.columnWidthArray[this.columnNo] + "px";
      this.label.classList.add(this.vGridConfig.css.rowHeaderCell);
      this.label.classList.add(this.vGridConfig.css.rowHeaderColumn + this.columnNo);
      this.label.classList.add(this.vGridConfig.css.gridColumn + this.columnNo);
      this.label.innerHTML = this.vGridConfig.headerArray[this.columnNo] +sortIcon;
      this.label.setAttribute(this.vGridConfig.atts.dataAttribute, this.attribute)
      var dragHandle = this.vGridConfig.isSortableHeader ? this.vGridConfig.css.dragHandle : "";
      if(dragHandle !== ""){
        this.label.classList.add(dragHandle);
      }
      this.label.classList.add(this.vGridConfig.css.cellContent);
      this.label.classList.add(this.vGridConfig.css.orderHandle);



      this.element.appendChild(this.label);

    }





    console.log("attached")
  }


  setStandardClassesAndStyles(){

    this.element.classList.add(this.vGridConfig.css.rowHeaderCell);
    this.element.classList.add(this.vGridConfig.css.rowHeaderColumn + this.columnNo)
    this.element.classList.add(this.vGridConfig.css.gridColumn + this.columnNo)
    this.element.style.height = '100%';
    this.element.style.width = this.vGridConfig.columnWidthArray[this.columnNo] + 'px';

  }

  getSortIcon(attribute) {
    var result;

    //setting lineheight so it stays in the middle
    var lineHeigthStyleTag;
    if (!this.vGridConfig.addFilter) {
      lineHeigthStyleTag = `style=line-height:${this.vGridConfig.headerHeight}px;"`;
    } else {
      lineHeigthStyleTag = `style=line-height:${this.vGridConfig.headerHeight / 2}px;"`;
    }

    if (this.vGridConfig.sortNotOnHeader.indexOf(attribute) !== -1) {
      return "";
    }


    if (this.vGridConfig.sortOnHeaderClick) {
      var main = `<span class=""><span ${lineHeigthStyleTag} class="${this.vGridConfig.css.sortIcon} ${this.vGridConfig.css.sortIconSort}"></span></span>`;
      if (this.vGrid.vGridGenerator.sortOrder.length === 0) {
        result = main
      } else {
        this.vGrid.vGridGenerator.sortOrder.forEach((x) => {
          if (x.attribute === attribute) {
            var isAsc = `<span ${lineHeigthStyleTag} class="${this.vGridConfig.css.sortIcon} ${this.vGridConfig.css.sortIconAsc}"></span>`;
            var isDesc = `<span ${lineHeigthStyleTag} class="${this.vGridConfig.css.sortIcon} ${this.vGridConfig.css.sortIconDesc}"></span>`;

            var asc = x.asc === true ? isAsc : isDesc;
            var main = `<span ${lineHeigthStyleTag} class="${this.vGridConfig.css.sortIcon} ${this.vGridConfig.css.sortIconNo}${x.no}">`;
            var end = '</span>';

            result = main + end + asc;
          }
        });
      }
      if (!result) {
        result = main;
      }
    } else {
      result = "";
    }
    return result
  };

}
