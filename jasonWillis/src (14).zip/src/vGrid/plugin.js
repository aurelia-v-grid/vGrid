export function configure(config) {
  config.globalResources('vGrid/v-grid-contextmenu', 'vGrid/v-grid-header-cells-label', 'vGrid/v-grid-header-cells-filter', 'vGrid/v-grid-row-cells-image', 'vGrid/v-grid-row-cells-checkbox', 'vGrid/v-grid-row-cells-input', 'vGrid/v-grid-col', 'vGrid/v-grid-header-col', 'vGrid/v-grid-row-col', 'vGrid/v-grid.js', 'vGrid/v-grid-atts');
}
