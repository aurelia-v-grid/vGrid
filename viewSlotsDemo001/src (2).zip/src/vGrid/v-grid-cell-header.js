/*****************************************************************************************************************
 *    VGridCellRow
 *    Custom element controlling the cell logic
 *    Created by vegar ringdal
 *
 ****************************************************************************************************************/
import {inject, noView, customElement, processContent, bindable} from 'aurelia-framework';
import {VGrid} from './v-grid'

//should I make this into a container and have cells under it?


@noView
@customElement('v-grid-cell-header')
@processContent(false)
@inject(Element, VGrid)
export class VGridCellRow {
  @bindable columnNo;




  constructor(element, vGrid) {
    this.element = element;
    this.vGrid = vGrid;
    this.vGridConfig = vGrid.vGridConfig;
  }


  bind(bindingContext) {
    this.bindingContext = bindingContext;
    console.log("nind")


  }


  created() {
    console.log("created")
  }


  attached() {
    this.setStandardClassesAndStyles();
    this.haveFilter = this.vGrid.vGridConfig.addFilter;
    this.attribute = this.vGrid.vGridConfig.attributeArray[this.columnNo];
    if(!this.haveFilter){
      this.label = document.createElement('div');
      this.label.style['line-height'] = this.vGridConfig.headerHeight + "px";
      this.label.style.height = "100%";
      this.label.style.width = this.vGridConfig.columnWidthArray[this.columnNo] + "px";
      this.label.classList.add(this.vGridConfig.css.rowHeaderCell);
      this.label.classList.add(this.vGridConfig.css.rowHeaderColumn + this.columnNo);
      this.label.classList.add(this.vGridConfig.css.gridColumn + this.columnNo);
      this.label.innerHTML = this.vGridConfig.headerArray[this.columnNo];
      this.label.setAttribute(this.vGridConfig.atts.dataAttribute, this.attribute)
      var dragHandle = this.vGridConfig.isSortableHeader ? this.vGridConfig.css.dragHandle : "";
      if(dragHandle !== ""){
        this.label.classList.add(dragHandle);
      }
      this.label.classList.add(this.vGridConfig.css.cellContent);
      this.label.classList.add(this.vGridConfig.css.orderHandle);



      this.element.appendChild(this.label);

    }





    console.log("attached")
  }


  setStandardClassesAndStyles(){

    this.element.classList.add(this.vGridConfig.css.rowHeaderCell);
    this.element.classList.add(this.vGridConfig.css.rowHeaderColumn + this.columnNo)
    this.element.classList.add(this.vGridConfig.css.gridColumn + this.columnNo)
    this.element.style.height = '100%';
    this.element.style.width = this.vGridConfig.columnWidthArray[this.columnNo] + 'px';

  }

}
