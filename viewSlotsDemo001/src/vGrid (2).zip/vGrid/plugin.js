export function configure(config) {
  config.globalResources('vGrid/v-grid-contextmenu','vGrid/v-grid-row-cells','vGrid/v-grid-col','vGrid/v-grid-header-col','vGrid/v-grid-row-col','vGrid/v-grid.js', 'vGrid/v-grid-atts');
}
