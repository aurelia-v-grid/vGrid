/*****************************************************************************************************************
 *    VGridRowCellInput
 *    Custom element for use in the row/column container (v-grid-row-col.js)
 *    Created by vegar ringdal
 *
 ****************************************************************************************************************/

//keeping one for each, so its easier to maintain if I do something special later

import {inject, noView, customElement, processContent, bindable} from 'aurelia-framework';
import {VGrid} from './v-grid'
import {VGridCellContainer} from './v-grid-row-col'


/*******************************************
 *  Normal input for text/numbers
 *******************************************/
@noView
@customElement('v-grid-input')
@processContent(false)
@inject(Element, VGrid)
export class VGridRowCellInput {
  @bindable value;

  
  constructor(element, vGrid) {
    this.element = element;
    this.vGrid = vGrid;
  }


  valueChanged(value, old) {
    if (value === undefined) {
      this.content.style.display = "none"
    } else {
      this.content.style.display = "block";
      this.content.value = value;
    }
  }

  bind(parent) {
    this.parent = parent;
  }

  attached() {
    this.content = this.element.children[0];//document.createElement("input");
    this.content.classList.add(this.parent.vGrid.vGridConfig.css.cellContent);
    this.content.style.height = "100%";
    this.content.style.width = "100%";
    this.element.appendChild(this.content);

    //set column no
    this.content.columnNo = parseInt(this.parent.columnNo);


    this.content.onchange = ()=> {
      this.parent.updateValue(this.content.value);
    };


    this.content.onblur = ()=> {
      this.parent.setValue(this.value);
      this.parent.setCss();
    };


    this.content.onkeydown = function (e) {
      if (this.parent.readOnly() === true && e.keyCode !== 9) {
        return false;
      } else {
        if (!this.parent.editMode()) {
          return false;
        } else {
          return true;
        }
      }
    }.bind(this);


    //called when tabbing etc
    this.content.addEventListener("cellFocus", function (e) {
      this.content.focus();
    }.bind(this));

  }


}


/*******************************************
 *  Normal input for checkbox
 *******************************************/
@noView
@customElement('v-grid-checkbox')
@processContent(false)
@inject(Element, VGrid, VGridCellContainer)
export class VGridRowCellCheckbox {
  @bindable value;


  constructor(element, vGrid, VGridCellContainer) {
    this.element = element;
    this.vGrid = vGrid;
    this.vGridCol = VGridCellContainer;
  }

  
  valueChanged(value, old) {
    if (value === undefined) {
      this.content.style.display = "none";
    } else {
      this.content.style.display = "block";
      this.content.checked = value;
    }
  }


  bind(parent) {
    this.parent = parent;
  }

  
  attached() {
    this.content = this.element.children[0];//document.createElement("input");
    this.content.type = "checkbox";
    this.content.onclick = function (e) {
      if (this.parent.readOnly() === true && e.keyCode !== 9) {
        return false;
      } else {
        if (!this.parent.editMode()) {
          return false;
        } else {
          return true;
        }
      }
    }.bind(this);
    this.content.classList.add(this.parent.vGrid.vGridConfig.css.cellContent);
    this.content.style.height = "100%";
    this.content.style.margin = "auto";
    this.content.style.display = "block";
    this.element.appendChild(this.content);

    this.content.onchange = ()=> {
      this.parent.updateValue(this.content.checked);
    };

    //set column no
    this.content.columnNo = parseInt(this.parent.columnNo);

    //called when tabbing etc
    this.content.addEventListener("cellFocus", function (e) {
      this.content.focus();
    }.bind(this));

  }
}


/*******************************************
 *  Normal input for image
 *******************************************/
@noView
@customElement('v-grid-image')
@processContent(false)
@inject(Element, VGrid, VGridCellContainer)
export class VGridRowCellImage {
  @bindable value;
  @bindable columnNo;


  constructor(element, vGrid, VGridCellContainer) {
    this.element = element;
    this.vGrid = vGrid;
    this.vGridCol = VGridCellContainer;
  }

  
  valueChanged(value, old) {
    if (value === undefined) {
      this.content.style.display = "none";
      this.content.src = "";
    } else {
      this.content.style.display = "block";
      this.content.src = value;
    }
  }


  bind(parent) {
    this.parent = parent;
  }


  attached() {
    this.content = this.element.children[0];//document.createElement("img");
    this.content.classList.add(this.parent.vGrid.vGridConfig.css.cellContent);
    this.valueChanged(this.value);
    this.content.style.margin = "auto";
    this.content.style.display = "none";
    this.element.appendChild(this.content);

    //set column no
    this.content.columnNo = parseInt(this.parent.columnNo);

    //called when tabbing etc
    this.content.addEventListener("cellFocus", function (e) {
      this.content.focus();
    }.bind(this));

  }


}
