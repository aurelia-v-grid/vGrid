/*****************************************************************************************************************
 *    VGridCellContainer
 *    Custom element controlling the cell logic
 *    Created by vegar ringdal
 *
 ****************************************************************************************************************/
import {inject, noView, customElement, processContent, Container, bindable,ViewSlot} from 'aurelia-framework';
import {VGrid} from './v-grid'


//should I make this into a container and have cells under it?


@noView
@customElement('v-grid-row-col')
@processContent(false)
@inject(Element, VGrid, Container)
export class VGridCellContainer {
  @bindable columnNo;





  constructor(element, vGrid, container) {
    this.element = element;
    this.container = container;
    this.vGrid = vGrid;
    this.hidden = false;
    this.displayRawValue = false;
    this.isRealFocus = false;
    this.value = "";

  }




  bind(bindingContext) {
    this.bindingContext = bindingContext;
    this.value = "";
    if(this.viewSlot && this.bindingContext){
      this.value = this.bindingContext[this.attribute()];
      this.rawValue = this.bindingContext[this.attribute()];
      this.setValue(this.value);
      if (this.vGrid.vGridCurrentRow === parseInt(this.element.parentNode.getAttribute("row"))) {
        if (parseInt(this.columnNo) === this.vGrid.vGridCellHelper.index) {
          if (!this.containsFocusClass(this.element)) {
            this.setCss()
          }
        }
      }
    }
  }


  created() {

  }


  attached() {

    this.setStandardClassesAndStyles();

    var that = this;

    switch (this.colType()) {
      case "image":
        var viewFactory = this.vGrid.viewCompiler.compile('<template><v-grid-image value.bind="value"></v-grid-image></template>', this.vGrid.resources);
        var view = viewFactory.create(this.container);
        this.viewSlot = new ViewSlot(this.element, true);
        this.viewSlot.add(view);
        this.viewSlot.bind(this);
        this.viewSlot.attached();
        break;
      case "checkbox":
        var viewFactory = this.vGrid.viewCompiler.compile('<template><v-grid-checkbox value.bind="value"></v-grid-checkbox></template>', this.vGrid.resources);
        var view = viewFactory.create(this.container);
        this.viewSlot = new ViewSlot(this.element, true);
        this.viewSlot.add(view);
        this.viewSlot.bind(this);
        this.viewSlot.attached();
        break;
      default:
        var viewFactory = this.vGrid.viewCompiler.compile('<template><v-grid-input column-no.bind="columnNo" value.bind="value"></v-grid-input></template>', this.vGrid.resources);
        var view = viewFactory.create(this.container);
        this.viewSlot = new ViewSlot(this.element, true);
        this.viewSlot.add(view);
        this.viewSlot.bind(this);
        this.viewSlot.attached();

    }


    this.element.addEventListener("cellFocus", function (e) {
      if (this.editMode()) {
        if (this.editRaw()) {
          if (!this.displayRawValue) {
            this.setValue(null, true);
            this.isRealFocus = true;
          }
        }
      }
      this.setCss();
    }.bind(this));


    this.element.ondblclick = function (e) {
      this.setEditMode(true);
    }.bind(this);

  }

  updateValue(value){
    this.vGrid.vGridCellHelper.updateActual({
      attribute: this.attribute(),
      value: this.valueFormater ? this.valueFormater.fromView(value) : value
    });
  }th

  /**************************************************
   set/get value and hide cell if not defined value
   */
  setValue(value, setRawValue) {
    this.removeCssCell();
    if (setRawValue) {
      this.value = this.rawValue;
      this.displayRawValue = true;
    } else {
      this.value = this.valueFormater ? this.valueFormater.toView(value) : value;
      this.displayRawValue = false;
    }


    // switch (this.colType()) {
    //   case "image":
    //     this.hideIfUndefined(value);
    //     if (value !== undefined && value !== null) {
    //       this.value = value;
    //     }
    //     break;
    //   case "checkbox":
    //     this.hideIfUndefined(value);
    //     this.value = value === "true" || value === true ? true : false;
    //     break;
    //   default:
    //     this.hideIfUndefined(value);
    //     if (setRawValue) {
    //       this.value = this.rawValue;
    //       this.displayRawValue = true;
    //     } else {
    //       this.value = this.valueFormater ? this.valueFormater.toView(value) : value;
    //       this.displayRawValue = false;
    //     }
    // }
  }


  getValue() {

    return this.valueFormater ? this.valueFormater.fromView(value) : value;

    // switch (this.colType()) {
    //   case "image":
    //     return value;
    //     break;
    //   case "checkbox":
    //     return value;
    //     break;
    //   default:
    //     return this.valueFormater ? this.valueFormater.fromView(value) : value;
    // }
  }


  hideIfUndefined(value) {
    // if (value === undefined) {
    //   this.hidden = true;
    //   //this.element.style.display = "none";
    //   this.removeCssOldCell();
    // } else {
    //   if (this.element.style.display === "none") {
    //     this.hidden = false;
    //     this.element.style.display = "block";
    //   }
    //  // this.cellContent.src = value;
    // }
  }


  /**************************************************
   basic types/atts
   */


  editMode() {
    return this.vGrid.vGridCellHelper.editMode;
  }


  setEditMode(value) {
    this.vGrid.vGridCellHelper.editMode = value;
  }

  editRaw() {
    return this.vGrid.vGridConfig.colEditRawArray[this.columnNo];
  }


  attribute() {
    return this.vGrid.vGridConfig.attributeArray[this.columnNo];
  }

  get valueFormater() {
    return this.vGrid.vGridConfig.colFormaterArray[this.columnNo];
  }

  readOnly() {
    return this.vGrid.vGridConfig.readOnlyArray[this.columnNo];
  }

  colType() {
    return this.vGrid.vGridConfig.colTypeArray[this.columnNo];
  }


  /**************************************************
   this and last element
   */

  getLastFocusElement() {
    return this.vGrid.vGridCellHelper.lastElement;
  }


  setLastFocusElement(element) {
    this.vGrid.vGridCellHelper.lastElement = element;
    if (this.editMode()) {
      this.lastEdit = true;
    } else {
      this.lastEdit = false;
    }

  }


  /**************************************************
   get and set classes
   */



  containsFocusClass(element) {
    if (element) {
      return element.classList.contains(this.vGrid.vGridConfig.css.editCellFocus)
    } else {
      return false;
    }
  }


  addFocusClass(element) {
    if (element) {
      //this.cellContent.setAttribute("readonly", "true");
      element.classList.add(this.vGrid.vGridConfig.css.editCellFocus)
    } else {
      return false;
    }
  }


  removeFocusClass(element) {
    if (element) {
      element.classList.remove(this.vGrid.vGridConfig.css.editCellFocus)
    } else {
      return false;
    }
  }


  containsWriteClass(element) {
    if (element) {
      return element.classList.contains(this.vGrid.vGridConfig.css.editCellWrite)
    } else {
      return false;
    }
  }


  addWriteClass(element) {
    if (element) {
      //this.cellContent.removeAttribute("readonly");
      element.classList.add(this.vGrid.vGridConfig.css.editCellWrite)
    } else {
      return false;
    }
  }


  removeWriteClass(element) {
    if (element) {


      element.classList.remove(this.vGrid.vGridConfig.css.editCellWrite)
    } else {
      return false;
    }
  }

  removeCssCell() {
    if (this.containsWriteClass(this.element)) {
      this.removeWriteClass(this.element);
    }
    if (this.containsFocusClass(this.element)) {
      this.removeFocusClass(this.element);
    }
  }


  removeCssOldCell() {
    if (this.containsWriteClass(this.getLastFocusElement())) {
      this.removeWriteClass(this.getLastFocusElement());
    }
    if (this.containsFocusClass(this.getLastFocusElement())) {
      this.removeFocusClass(this.getLastFocusElement());
    }
  }


  setCss() {
    if (!this.containsFocusClass(this.element)) {
      this.addFocusClass(this.element);
      this.removeCssOldCell();
      this.setLastFocusElement(this.element)
    }

    if (this.editMode() && !this.readOnly()) {
      if (!this.containsWriteClass(this.element)) {
        this.removeFocusClass(this.element);
        this.addWriteClass(this.element);
      }
    }
  }

  setStandardClassesAndStyles() {
    var css = this.vGrid.vGridConfig.css;
    var cellStyle = `width:${this.vGrid.vGridConfig.columnWidthArray[this.columnNo]}px`;
    this.element.classList.add(css.rowCell);
    this.element.classList.add(css.rowColumn + this.columnNo);
    this.element.classList.add(css.gridColumn + this.columnNo);
    this.element.setAttribute("style", cellStyle);
  }


}
