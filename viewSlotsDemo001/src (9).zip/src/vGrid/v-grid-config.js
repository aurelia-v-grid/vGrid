/*****************************************************************************************************************
 *    VGridConfig
 *    This generates the config used by vGridgenerator, other classes also calls this to get the information
 *    Created by vegar ringdal
 *
 ****************************************************************************************************************/

export class VGridConfig {


  /***************************************************************************************
   * CSS classes used by grid
   ***************************************************************************************/
  css = {
    wrapper: "vGrid",
    row: "vGrid-row",
    mainHeader: "vGrid-header",
    mainContent: "vGrid-body",
    mainFooter: "vGrid-footer",
    scrollBody: "vGrid-body-scroll",
    rowCell: "vGrid-row-cell",
    rowColumn: "vGrid-row-column",
    rowHeaderCell: "vGrid-row-cell-header",
    rowHeaderColumn: "vGrid-row-column-header",
    gridColumn: "vGrid-column",
    rowHeader: "vGrid-row-header",
    rowSelected: "vGrid-row-selected",
    rowContainer: "vGrid-row-container",
    rowAlt: "vGrid-row-alt",
    rowEven: "vGrid-row-even",
    editCell: "vGrid-editCell",
    editCellWrite: "vGrid-editCell-write",
    editCellFocus: "vGrid-editCell-focus",
    filterLabelTop: "vGrid-filterLabelAtTop",
    filterLabelBottom: "vGrid-filterLabelAtBottom",
    filterInputTop: "vGrid-filterInputAtTop",
    filterInputBottom: "vGrid-filterInputAtBottom",
    cellContent: "vGrid-content",
    dragHandle: "vGrid-vGridDragHandle",
    filterHandle: "vGrid-queryField",
    orderHandle: "v-grid-header-orderBy",
    resizeHeaderDragHandle: "vGrid-draggable-handler",
    sortIcon: "vGrid-glyphicon",
    sortIconSort: "vGrid-glyphicon-sort",
    sortIconAsc: "vGrid-glyphicon-sort-asc",
    sortIconDesc: "vGrid-glyphicon-sort-desc",
    sortIconNo: "vGrid-glyphicon-",
    noData: "vGrid-row-no-data"
  };


  /***************************************************************************************
   * different attributes used by grid
   ***************************************************************************************/
  atts = {
    dataAttribute: "v-grid-data-attribute",
    dataAttributeFilter: "v-grid-data-attribute-filter"
  };

  bind() {
    debugger;
  }

  constructor(vGrid) {
    this.vGrid = vGrid;


    this.columns = [];
    this.attributeArray = [];
    this.columnWidthArray = [];
    this.headerArray = [];
    this.filterArray = [];
    this.readOnlyArray = [];
    this.colStyleArray = [];
    this.colTypeArray = [];

    this.rowHeight = 50;
    this.headerHeight = 0;
    this.footerHeight = 0;
    this.isResizableHeaders = false;
    this.isMultiSelect = undefined;
    this.isSortableHeader = false;
    this.requestAnimationFrame = true;
    this.resizableHeadersAndRows = false;
    this.renderOnScrollbarScroll = true;
    this.addFilter = false;
    this.filterOnAtTop = false;
    this.filterOnKey = false;
    this.sortOnHeaderClick = false;
    this.largeBuffer = false;
    this.activeSorting = false;

    this.eventOnRowDraw = null;


    this.doNotAddFilterTo = [];
    this.sortNotOnHeader = [];

    //todo create attribute
    this.dataScrollDelay = 200;


  }


  get vGridCellHelper(){
    if(this.vGrid){
      return this.vGrid.vGridCellHelper;
    } else {
      return null;
    }
  }
  get vGridFilter(){
    if(this.vGrid){
      return this.vGrid.vGridFilter;
    } else {
      return null;
    }
  }

  get vGridSort(){
    if(this.vGrid){
      return this.vGrid.vGridSort;
    } else {
      return null;
    }
  }

  get vGridGenerator(){
    if(this.vGrid){
      return this.vGrid.vGridGenerator;
    } else {
      return null;
    }
  }


  //from string interpolate, this is whats passes into the onrowdraw event, so we dont end up with people enditing their collection
  attributes = [];

  getNewObject(obj) {
    if (obj) {
      var x = {};
      this.attributes.forEach((prop)=> {
        x[prop] = obj[prop];
      });
      return x;
    } else {
      return "";
    }
  }


  /***************************************************************************************
   * This is called when grid runs filter
   ***************************************************************************************/

  onFilterRun = (filterObj) => {

    if (filterObj.length !== 0 || this.vGrid.vGridCollectionFiltered.length !== this.vGrid.vGridCollection.length) {
      //get sel keys

      //if they filter we want to make sure the after cell edit happends
      if (this.vGridCellHelper.curElement && this.vGridCellHelper.updated === false) {
        this.vGridCellHelper.updateActual(this.vGridCellHelper.callbackObject());
      }

      var curKey = -1;
      if (this.vGrid.vGridCurrentEntityRef) {
        curKey = this.vGrid.vGridCurrentEntityRef[this.vGrid.vGridRowKey];
      }
      if (filterObj.length === 0 && this.vGrid.vGridCollectionFiltered.length !== this.vGrid.vGridCollection.length) {
        this.vGrid.vGridCollectionFiltered = this.vGrid.vGridCollection.slice(0);
      } else {

        this.vGrid.vGridCollectionFiltered = this.vGridFilter.run(this.vGrid.vGridCollection, filterObj);
        this.vGridSort.run(this.vGrid.vGridCollectionFiltered);

      }


      //set current row/entity in sync
      var newRowNo = -1;
      if (curKey) {
        this.vGrid.vGridCollectionFiltered.forEach((x, index) => {
          if (curKey === x[this.vGrid.vGridRowKey]) {
            newRowNo = index;
          }
        });
      }


      if (newRowNo > -1) {
        this.vGrid.vGridCurrentEntityRef = this.vGrid.vGridCollectionFiltered[newRowNo];
        this.vGrid.vGridCurrentEntity[this.vGrid.vGridRowKey] = this.vGrid.vGridCurrentEntityRef[this.vGrid.vGridRowKey];
        this.vGrid.vGridCurrentRow = newRowNo;
      }

      //update grid
      this.vGridGenerator.collectionChange(true);


    }

  };


  /***************************************************************************************
   * grid asks for the filter name from attibute
   ***************************************************************************************/
  getFilterName(name) {
    return this.vGridFilter.getNameOfFilter(name)
  }


  /***************************************************************************************
   * This just sets data from array,
   * Use {} if you want markup of columns, or undefined for total blank rows
   ***************************************************************************************/
  getDataElement(row, isDown, isLargeScroll, callback) {
    if (this.vGrid.vGridCollectionFiltered !== undefined) {
      if (this.eventOnRowDraw) {
        //if user have added this then we call it so they can edit the row data before we display it
        var data = this.getNewObject(this.vGrid.vGridCollectionFiltered[row]);
        this.eventOnRowDraw(data, this.vGrid.vGridCollectionFiltered[row]);
        callback(data)
      } else {
        callback(this.vGrid.vGridCollectionFiltered[row]);
      }
    }
  }





  /***************************************************************************************
   * This calls the order by function
   * Use {} if you want markup of columns, or undefined for total blank rows
   ***************************************************************************************/
  onOrderBy(event, setheaders) {

    //if they sort we want to make sure the after cell edit happends
    if (this.vGridCellHelper.curElement && this.vGridCellHelper.updated === false) {
      this.vGridCellHelper.updateActual(this.vGridCellHelper.callbackObject());
    }


    //get clicked
    var attribute = event.target.getAttribute(this.atts.dataAttribute);
    if (attribute === null) {
      attribute = event.target.offsetParent.getAttribute(this.atts.dataAttribute);
    }
    let checked = true;
    if (this.sortNotOnHeader.indexOf(attribute) !== -1) {
      checked = false;
    }

    if (this.vGrid.vGridCollectionFiltered.length > 0 && attribute && checked) {

      //set filter
      this.vGridSort.setFilter({
        attribute: attribute,
        asc: true
      }, event.shiftKey);
      //set headers
      setheaders(this.vGridSort.getFilter());
      //get sel keys

      //run filter
      this.vGridSort.run(this.vGrid.vGridCollectionFiltered);


      //set new row
      this.vGrid.vGridCollectionFiltered.forEach((x, index) => {
        if (this.vGrid.vGridCurrentEntity[this.vGrid.vGridRowKey] === x[this.vGrid.vGridRowKey]) {
          this.vGrid.vGridCurrentRow = index;
        }
      });

      //update grid
      this.vGridGenerator.collectionChange();

    }


  }





  /***************************************************************************************
   * Just for knowing length,
   * Its this you will need to add for server source/paging with endless scrolling
   ***************************************************************************************/
  getCollectionLength() {
    if (this.addFilter) {
      return this.vGrid.vGridCollectionFiltered.length;
    } else {
      return this.vGrid.vGridCollection.length;
    }
  }




  /***************************************************************************************
   * Listen for click on rows,
   * Snd set current entity, and also allow edit of cell
   ***************************************************************************************/
  clickHandler(event, row) {


    //set current row of out filtered row
    this.vGrid.vGridCurrentRow = row;

    //get data ref
    this.vGrid.vGridCurrentEntityRef = this.vGrid.vGridCollectionFiltered[row];

    ///loop properties and set them to current entity
    let data = this.vGrid.vGridCurrentEntityRef;
    for (var k in data) {
      if (data.hasOwnProperty(k)) {
        if (this.vGrid.vGridCurrentEntity[k] !== data[k]) {
          this.vGrid.vGridCurrentEntity[k] = data[k];
          this.vGrid.vGridSkipNextUpdateProperty.push(k)
        }
      }
    }


     //use helper function to edit cell
   if(this.vGrid.vGridCurrentEntityRef){
     this.vGridCellHelper.editCellhelper(row, event);
   }

  }


}
