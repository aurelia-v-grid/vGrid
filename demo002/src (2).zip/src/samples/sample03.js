
export class sample03 {


  constructor(){

  }






}
