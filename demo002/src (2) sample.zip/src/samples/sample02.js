
export class sample02 {


  constructor(){

  }






}
