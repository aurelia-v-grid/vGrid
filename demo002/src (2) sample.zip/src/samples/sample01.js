import {dummyDataGenerator} from 'data/dummyDataGenerator'
import hljs from 'highlight.js';
import 'highlight.js/styles/ir-black.css!';

export class sample01 {
  static inject = [Element, dummyDataGenerator];


  myCollection = [];
  myCurrentEntity = {};
  myGrid = {
    onRowDraw: function (data) {
      if (data) {
        if (data.country === "Angola") {
          data.myCustomColor = "rgba(150,72,230, 0.3)"
        }
      }
    }
  };


  /********************************************************************
   * Constructor
   ********************************************************************/
  constructor(element, dummyDataGenerator) {
    //get this element
    this.element = element;

    //this if just for giving us some data
    this.dummyDataGenerator = dummyDataGenerator;
    this.dummyDataGenerator.generateData(100, (data) => {
      this.myCollection = data;
    });

  }



  /********************************************************************
   *  COLLECTION MOD BUTTONS
   ********************************************************************/

  replaceBtn(x) {
    //generate and add
    this.dummyDataGenerator.generateData(x, (data) => {
      this.myCollection = data;
    })
  }

  addBtn(x) {
    //generate and add
    this.dummyDataGenerator.generateData(x, (data) => {
      data.forEach((x) => {
        this.myCollection.push(x)
      })
    })
  }

  removeFirstBtn() {
    this.myCollection.splice(0, 1);
  }

  removeLastBtn() {
    this.myCollection.pop();
  }

  removeFirst100Btn() {
    this.myCollection.splice(0, 100);

  }


  removeLast100Btn() {
    this.myCollection.splice(this.myCollection.length - 100, 100);

  }


  /********************************************************************
   * GRID-CONTEXT BUTTONS
   ********************************************************************/

  status = {
    noSelect : "lightgrey",
    header50: "lightgrey",
    row25: "lightgrey",
    footer0:"lightgrey",
    sortable1:"lightgrey"

  };

  rowHeightBtn(x) {

    this.myGrid.ctx.setRowHeight(x)
    this.status.row25 = "";
    this.status.row50 = "";
    this.status.row75 = "";
    this.status.row100 = "";

    switch(x){
      case 25:
        this.status.row25 = "lightgrey";
        break;
      case 50:
        this.status.row50 = "lightgrey";
        break;
      case 75:
        this.status.row75 = "lightgrey";
        break;
      case 100:
        this.status.row100 = "lightgrey";
        break;
    }
  }



  headerHeightBtn(x) {
    this.myGrid.ctx.setHeaderHeight(x)
    this.status.header0 = "";
    this.status.header25 = "";
    this.status.header50 = "";
    this.status.header75 = "";

    switch(x){
      case 0:
        this.status.header0 = "lightgrey";
        break;
      case 25:
        this.status.header25 = "lightgrey";
        break;
      case 50:
        this.status.header50 = "lightgrey";
        break;
      case 75:
        this.status.header75 = "lightgrey";
        break;
    }
  }



  footerHeightBtn(x) {
    this.myGrid.ctx.setFooterHeight(x)
    this.status.footer0 = "";
    this.status.footer25 = "";
    this.status.footer50 = "";
    this.status.footer75 = "";

    switch(x){
      case 0:
        this.status.footer0 = "lightgrey";
        break;
      case 25:
        this.status.footer25 = "lightgrey";
        break;
      case 50:
        this.status.footer50 = "lightgrey";
        break;
      case 75:
        this.status.footer75 = "lightgrey";
        break;
    }
  }




  selectionBtn(x){

    this.status.noSelect = "";
    this.status.singleSelect = "";
    this.status.multiSelect = "";

    switch(x){
      case 0:
        this.myGrid.ctx.selection.reset();
        this.myGrid.ctx.disableSelection();
        this.status.noSelect = "lightgrey";
        break;
      case 1:
        this.myGrid.ctx.selection.reset();
        this.myGrid.ctx.setSingleSelection();
        this.status.singleSelect = "lightgrey";
        break;
      case 2:
        this.myGrid.ctx.selection.reset();
        this.myGrid.ctx.setMultiSelection();
        this.status.multiSelect = "lightgrey";
        break;
    }
  }

  sortableBtn(x){
    this.status.footer0 = "";
    this.status.footer25 = "";
    this.status.footer50 = "lightgrey";
    this.status.footer75 = "";
    switch(x){
      case 0:
        this.headerHeightBtn(50);
        this.myGrid.ctx.disableSortableColumns();
        this.status.sortable0 = "lightgrey";
        this.status.sortable1 = "";
        break;
      case 1:
        this.headerHeightBtn(50);
        this.myGrid.ctx.enableSortableColumns();
        this.status.sortable0 = "";
        this.status.sortable1 = "lightgrey";
        break;

    }
  }



  /********************************************************************
   * attached
   ********************************************************************/
  attached() {

    // var myCodeBlock = this.element.getElementsByTagName("TEXTAREA")[0]
    // var x = document.createElement("code");
    // x.classlist = myCodeBlock.classList;
    // x.style = myCodeBlock.style;
    // x.innerHTML = myCodeBlock.innerHTML;
    // myCodeBlock.parentNode.replaceChild(x, myCodeBlock);
    // hljs.highlightBlock(myCodeBlock);
  }




}
